﻿README

Name: 
    	Eliza

Synopsis:
   	 Eliza is a chatbot program that allows users to have an interactive conversation with her. 

Initial Setup:
   	 Install Clisp (Required to run the program)

Instructions:
    	To begin chatting with Eliza, you must first start the program.
    	To start the program enter the following command.
    
    	  Command for starting the Eliza program    
    	/------------------------------------------------------------------/
    	 clisp -i /path/to/eliza_starter.lisp

    	After that, you can begin to talk with Eliza by using the following syntax. 
   	Replace “your message” with what you want to say to her.

    	 Command for talking with Eliza
    	/------------------------------------------------------------------/
    	 (eliza ‘(your message))


Notes:
	Do not send messages with only special characters. Messages with only special characters may cause the program to crash or stall.
	
